import logging
import datetime
import os
import re
import sys
import numpy as np
import random
import torch


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
OUTPUT_ROOT = os.path.join(PROJECT_ROOT, "outputs")
CACHE_ROOT = os.path.join(PROJECT_ROOT, "cache")


def _slugify(value):
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", str(value)).strip("-") or "unknown"


def build_run_id(task, model, dataset):
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    return "__".join([timestamp, _slugify(task), _slugify(model), _slugify(dataset)])


def ensure_run_id(config):
    exp_id = config.get("exp_id", None)
    if not exp_id:
        exp_id = build_run_id(config.get("task", "task"), config.get("model", "model"), config.get("dataset", "dataset"))
        config["exp_id"] = exp_id
    return exp_id


def get_output_root():
    ensure_dir(OUTPUT_ROOT)
    return OUTPUT_ROOT


def get_cache_root():
    ensure_dir(CACHE_ROOT)
    return CACHE_ROOT


def get_cache_subdir(*parts):
    path = os.path.join(get_cache_root(), *parts)
    ensure_dir(path)
    return path


def get_dataset_cache_dir():
    return get_cache_subdir("dataset_cache")


def get_dataset_cache_path(*parts):
    return os.path.join(get_dataset_cache_dir(), *parts)


def get_run_dir(exp_id):
    run_dir = os.path.join(get_output_root(), str(exp_id))
    ensure_dir(run_dir)
    return run_dir


def get_run_subdir(exp_id, *parts):
    path = os.path.join(get_run_dir(exp_id), *parts)
    ensure_dir(path)
    return path


def get_executor(config, model, data_feature):
    """
    according the config['executor'] to create the executor

    Args:
        config(ConfigParser): config
        model(AbstractModel): model

    Returns:
        AbstractExecutor: the loaded executor
    """
    from libcity.executor.registry import get_executor_class

    executor_class = get_executor_class(config['executor'])
    return executor_class(config, model, data_feature)


def get_model(config, data_feature):
    """
    according the config['model'] to create the model

    Args:
        config(ConfigParser): config
        data_feature(dict): feature of the data

    Returns:
        AbstractModel: the loaded model
    """
    from libcity.model.registry import get_model_class

    model_class = get_model_class(config['task'], config['model'])
    return model_class(config, data_feature)


def get_evaluator(config):
    """
    according the config['evaluator'] to create the evaluator

    Args:
        config(ConfigParser): config

    Returns:
        AbstractEvaluator: the loaded evaluator
    """
    from libcity.evaluator.registry import get_evaluator_class

    evaluator_class = get_evaluator_class(config['evaluator'])
    return evaluator_class(config)


def get_logger(config, name=None):
    """
    获取Logger对象

    Args:
        config(ConfigParser): config
        name: specified name

    Returns:
        Logger: logger
    """
    ensure_run_id(config)
    log_dir = get_run_subdir(config['exp_id'], 'logs')
    log_filename = 'run.log'
    logfilepath = os.path.join(log_dir, log_filename)

    logger = logging.getLogger(name)

    log_level = config.get('log_level', 'INFO')

    if log_level.lower() == 'info':
        level = logging.INFO
    elif log_level.lower() == 'debug':
        level = logging.DEBUG
    elif log_level.lower() == 'error':
        level = logging.ERROR
    elif log_level.lower() == 'warning':
        level = logging.WARNING
    elif log_level.lower() == 'critical':
        level = logging.CRITICAL
    else:
        level = logging.INFO

    logger.setLevel(level)

    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler = logging.FileHandler(logfilepath)
    file_handler.setFormatter(formatter)

    console_formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s')
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(console_formatter)

    if not any(isinstance(handler, logging.FileHandler) and getattr(handler, "baseFilename", None) == os.path.abspath(logfilepath)
               for handler in logger.handlers):
        logger.addHandler(file_handler)
    if not any(isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler)
               for handler in logger.handlers):
        logger.addHandler(console_handler)

    logger.info('Log directory: %s', log_dir)
    return logger


def get_local_time():
    """
    获取时间

    Return:
        datetime: 时间
    """
    cur = datetime.datetime.now()
    cur = cur.strftime('%b-%d-%Y_%H-%M-%S')
    return cur


def ensure_dir(dir_path):
    """Make sure the directory exists, if it does not exist, create it.

    Args:
        dir_path (str): directory path
    """
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)


def trans_naming_rule(origin, origin_rule, target_rule):
    """
    名字转换规则

    Args:
        origin (str): 源命名格式下的变量名
        origin_rule (str): 源命名格式，枚举类
        target_rule (str): 目标命名格式，枚举类

    Return:
        target (str): 转换之后的结果
    """
    # TODO: 请确保输入是符合 origin_rule，这里目前不做检查
    target = ''
    if origin_rule == 'upper_camel_case' and target_rule == 'under_score_rule':
        for i, c in enumerate(origin):
            if i == 0:
                target = c.lower()
            else:
                target += '_' + c.lower() if c.isupper() else c
        return target
    else:
        raise NotImplementedError(
            'trans naming rule only support from upper_camel_case to \
                under_score_rule')


def preprocess_data(data, config):
    """
    split by input_window and output_window

    Args:
        data: shape (T, ...)

    Returns:
        np.ndarray: (train_size/test_size, input_window, ...)
                    (train_size/test_size, output_window, ...)

    """
    train_rate = config.get('train_rate', 0.7)
    eval_rate = config.get('eval_rate', 0.1)

    input_window = config.get('input_window', 12)
    output_window = config.get('output_window', 3)

    x, y = [], []
    for i in range(len(data) - input_window - output_window):
        a = data[i: i + input_window + output_window]  # (in+out, ...)
        x.append(a[0: input_window])  # (in, ...)
        y.append(a[input_window: input_window + output_window])  # (out, ...)
    x = np.array(x)  # (num_samples, in, ...)
    y = np.array(y)  # (num_samples, out, ...)

    train_size = int(x.shape[0] * (train_rate + eval_rate))
    trainx = x[:train_size]  # (train_size, in, ...)
    trainy = y[:train_size]  # (train_size, out, ...)
    testx = x[train_size:x.shape[0]]  # (test_size, in, ...)
    testy = y[train_size:x.shape[0]]  # (test_size, out, ...)
    return trainx, trainy, testx, testy


def set_random_seed(seed):
    """
    重置随机数种子

    Args:
        seed(int): 种子数
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
